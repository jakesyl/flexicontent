<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
require_once(JPATH_BASE.DS."administrator".DS."components".DS."com_flexicontent".DS."controllers".DS."filemanager.php");
?>