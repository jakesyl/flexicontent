<?php
defined('JPATH_BASE') or die;
require_once(JPATH_ADMINISTRATOR.DS."components".DS."com_categories".DS."models".DS."fields".DS."categoryparent.php");
?>